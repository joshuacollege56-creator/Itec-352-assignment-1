# Playlist Manager Activity — Starter Files

Files included:
- playlist.py       : Starter module students will edit/complete.
- test_playlist.py  : Simple assert-based tests for local verification.


How to use:
1. Unzip the distribution.
